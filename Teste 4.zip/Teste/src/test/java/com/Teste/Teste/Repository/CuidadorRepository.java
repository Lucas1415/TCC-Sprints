package com.Teste.Teste.Repository;




import com.Teste.Teste.Models.Cuidador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CuidadorRepository extends JpaRepository<Cuidador, Integer> {
    //os metodos do crud ja estao implementados
}
