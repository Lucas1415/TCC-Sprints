package com.Teste.Teste.Models;



import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table
public class Usuario {
    //ID,Nome, Email, Senha
    @jakarta.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer Id;
    @Column(length = 50, nullable = false)

    private String Name;
    @Column(length = 100)

    private String  Email;
    @Column(length = 100)

    private String Senha;

    public Usuario(Integer id, String name, String email, String senha) {
        Id = id;
        Name = name;
        Email = email;
        Senha = senha;
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String senha) {
        Senha = senha;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return Objects.equals(Id, usuario.Id) && Objects.equals(Name, usuario.Name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(Id, Name);
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "Id=" + Id +
                ", Name='" + Name + '\'' +
                '}';
    }
}
