package com.Teste.Teste.Controller;



import com.Teste.Teste.Models.Cuidador;
import com.Teste.Teste.Repository.CuidadorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/cuidador")
public class CuidadorController {
    //id, idade, nome,localizaçao
// o mapping le o metodo e executa de acordo com cada funçao
    @Autowired
    private CuidadorRepository repository;

    @GetMapping
    public List<Cuidador> All() {
        return repository.findAll();
    }

    @GetMapping("/cuidador/{id}")
    public Optional<Cuidador> one(@PathVariable Integer id) {
        return repository.findById(id);
    }

    @DeleteMapping("/cuidador/{id}")
    public void delete(@PathVariable Integer id) {
        repository.deleteById(id);
    }

    @PostMapping
    public Cuidador save(@RequestBody Cuidador newCuidador) {
        return repository.save(newCuidador);
    }

    @PutMapping
    public Cuidador update(@RequestBody Cuidador newCuidador, @PathVariable Integer id) {
        return repository.findById(id)
                .map(Cuidador -> {
                    Cuidador.setName(newCuidador.getName());
                    Cuidador.setIdade(newCuidador.getIdade());
                    Cuidador.setLocalizacao(newCuidador.getLocalizacao());
                    return repository.save(Cuidador);
                })
                .orElseGet(() -> {
                    return repository.save(newCuidador);
                });
    }
}
