package com.Teste.Teste.Repository;




import com.Teste.Teste.Models.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PacienteRepository extends JpaRepository<Paciente, Integer> {
}
