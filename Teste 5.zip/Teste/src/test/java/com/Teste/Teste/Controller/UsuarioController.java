package com.Teste.Teste.Controller;

import com.Teste.Teste.Models.Usuario;
import com.Teste.Teste.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/usuario") // Define o recurso da API
public class UsuarioController {

    @Autowired
    private UsuarioRepository repository;

    // Retorna todos os usuários
    @GetMapping
    public List<Usuario> all() {
        return repository.findAll();
    }

    // Retorna um usuário específico por ID
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> one(@PathVariable Long id) { // Alterado para Long
        return repository.findById(id)
                .map(usuario -> ResponseEntity.ok(usuario))
                .orElse(ResponseEntity.notFound().build());
    }

    // Deleta um usuário por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) { // Alterado para Long
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.noContent().build(); // 204 No Content
        } else {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
    }

    // Cadastro de novo usuário
    @PostMapping
    public ResponseEntity<Usuario> save(@RequestBody Usuario newUsuario) {
        Usuario savedUsuario = repository.save(newUsuario);
        return ResponseEntity.status(201).body(savedUsuario); // 201 Created
    }

    // Método para login
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Usuario loginData) {
        String email = loginData.getEmail();
        String senha = loginData.getSenha();

        Usuario usuario = repository.findByEmail(email);
        if (usuario != null && usuario.getSenha().equals(senha)) {
            return ResponseEntity.ok("Login bem-sucedido!"); // Retornar o token se implementar
        } else {
            return ResponseEntity.status(401).body("E-mail ou senha incorretos"); // 401 Unauthorized
        }
    }

    // Atualiza um usuário por ID
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> update(@RequestBody Usuario newUsuario, @PathVariable Long id) { // Alterado para Long
        return repository.findById(id)
                .map(usuario -> {
                    usuario.setName(newUsuario.getName());
                    usuario.setEmail(newUsuario.getEmail());
                    usuario.setSenha(newUsuario.getSenha());
                    Usuario updatedUsuario = repository.save(usuario);
                    return ResponseEntity.ok(updatedUsuario); // 200 OK
                })
                .orElse(ResponseEntity.notFound().build()); // 404 Not Found
    }
}
