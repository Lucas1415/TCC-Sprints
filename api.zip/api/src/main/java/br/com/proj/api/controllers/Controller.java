package br.com.proj.api.controllers;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@RestController // responsavel por avisar para o spring que essa classe vai ser responsavel pela rota 
public class Controller {
    
    @GetMapping("")
    public String mensagem(){
        return "Hello world";
    }

    @GetMapping("/boasVindas{nome}")// o spring pega a informaçao da url e trata como uma variavel 
    public String boasVindas(@PathVariable String nome){
        return "Seja bem-vindo(a) " + nome;
    }
}
