import React, { useEffect, useState } from "react";
import { AuthProvider } from './contexts/auth'; // Importando o AuthProvider
import RouterApp from './routes';
import GlobalStyle from './global';
import './App.css';

const App = () => {
  return (
    <AuthProvider>
      <RouterApp />
      
      <GlobalStyle />
    </AuthProvider>
  );
};

export default App;
