import React, { useEffect, useState } from 'react';
import Card from './Card';
import { Container } from './style';

const CardContainer = ({ rotinas }) => {
  // Vamos assumir que rotinas já foi passada como props de `Domingo`

  return (
    <Container>
      {rotinas.length === 0 ? (
        <div>Nenhuma rotina disponível</div>
      ) : (
        rotinas.map(rotina => (
          <Card
            key={rotina.id}
            imageSrc={rotina.imageSrc || '../images/default.jpg'}  // Verifica se a imagem existe
            title={rotina.title}  // Puxa o título da rotina
            description={rotina.description}  // Puxa a descrição da rotina
          />
        ))
      )}
    </Container>
  );
};

export default CardContainer;
