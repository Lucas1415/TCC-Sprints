import React, { useEffect, useState } from 'react';
import Card from './Card';
import { Container } from './style';

const CardContainer = () => {
  const [rotinas, setRotinas] = useState([]);  // Estado para armazenar os dados da API
  const [loading, setLoading] = useState(true);  // Estado para controle de carregamento
  const [error, setError] = useState(null);  // Estado para capturar erros de requisição

  useEffect(() => {
    // Função para buscar as rotinas da API
    const fetchRotinas = async () => {
      try {
        const response = await fetch("http://localhost:8080/api/rotina");  // Altere a URL conforme o seu servidor
        
        if (!response.ok) {
          throw new Error('Erro na requisição');
        }

        const data = await response.json();

        // Verifica se data é um array, caso contrário, define como um array vazio
        if (Array.isArray(data)) {
          setRotinas(data);
        } else {
          setRotinas([]);  // Caso o dado não seja um array, define como vazio
        }

      } catch (error) {
        setError(error.message);  // Armazena a mensagem de erro no estado
      } finally {
        setLoading(false);  // Define loading como false após a requisição
      }
    };

    fetchRotinas();  // Chama a função ao carregar o componente
  }, []);  // O array vazio faz com que o efeito seja executado uma vez ao carregar o componente

  // Caso os dados ainda estejam carregando
  if (loading) {
    return <div>Carregando...</div>;
  }

  // Caso haja erro na requisição
  if (error) {
    return <div>Erro: {error}</div>;
  }

  return (
    <Container>
      {rotinas.length === 0 ? (
        <div>Nenhuma rotina disponível</div>
      ) : (
        rotinas.map(rotina => (
          <Card
            key={rotina.id}
            imageSrc={rotina.imageSrc || '../images/default.jpg'}  // Verifica se a imagem existe
            title={rotina.title}  // Puxa o título da rotina
            description={rotina.description}  // Puxa a descrição da rotina
          />
        ))
      )}
    </Container>
  );
};

export default CardContainer;
