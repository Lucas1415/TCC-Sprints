import React, { useContext, useState } from 'react';
import { AuthContext } from "../contexts/auth";

function useAuth() {
  const { signin } = useContext(AuthContext);  // Acessa a função de login do contexto
  const [email, setEmail] = useState("");      // Estado para o email
  const [senha, setSenha] = useState("");      // Estado para a senha
  const [error, setError] = useState("");      // Estado para armazenar erros

  const handleLogin = async (e) => {
    e.preventDefault();  // Impede o comportamento padrão do form

    // Verifica se o email ou a senha estão vazios
    if (!email || !senha) {
      setError("Por favor, preencha todos os campos.");
      return;
    }

    try {
      // Chama a função signin do contexto para realizar o login
      const message = await signin(email, senha);

      if (message !== "Login bem-sucedido!") {
        setError(message);  // Se a resposta não for de sucesso, exibe o erro
      } else {
        setError("");  // Reseta o erro se o login foi bem-sucedido
      }
    } catch (error) {
      setError("Erro ao tentar fazer login.");
      console.error("Erro no login:", error);
    }
  };

  return { email, setEmail, senha, setSenha, error, handleLogin };
}

export default useAuth;
