import React,{useEffect,useState}from"react";
import Api from"../../Api/Api.js"; // Importa a configuração do Axios

const UsuariosList=()=>{const[usuarios,setUsuarios]=useState([]);

useEffect(()=>{api.get("/usuarios").then((response)=>{setUsuarios(response.data); // Atualiza o estado com a lista de
                                                                                  // usuários
}).catch((error)=>{console.error("Erro ao buscar usuários:",error);});},[]);

return(<div><h1>Lista de Usuários</h1><ul>{usuarios.map((usuario)=>(<li key={usuario.id}>{usuario.name}</li>))}</ul></div>);};

export default UsuariosList;
