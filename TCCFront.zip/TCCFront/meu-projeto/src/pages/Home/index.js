import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../components/Button';
import useAuth from '../../hooks/useAuth';
import * as C from "./style";
import { Link } from 'react-router-dom';
import WeekTable from '../../components/WeekTable/WeekTable'; // Importe o WeekTable

const Home = () => {
    const { signout } = useAuth();
    const navigate = useNavigate();

    const handleSignout = () => {
        signout();
        navigate('/');
    };

    return (
        <C.MenuContainer>
                <script src="//code.tidio.co/7d5krcbcz0g5bfz4ebh0irgo2rnirhnt.js"></script>
           <C.Menu>
            <C.MenuItem>
                <Link to="/home">Home</Link>
            </C.MenuItem>
            <C.MenuItem>
                <Link to="/semana">Semana</Link>
            </C.MenuItem>
            <C.MenuItem>
                <Link to="Cuidador">Cuidador</Link>
            </C.MenuItem>
           </C.Menu>
           <C.InicialConteiner>
                
                <WeekTable />
            </C.InicialConteiner>
          
        </C.MenuContainer>
    );
};

export default Home;
