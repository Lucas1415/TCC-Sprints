import React from 'react';

const Home = () =>{
    return(
        <div>index</div>
    )
}

export default index