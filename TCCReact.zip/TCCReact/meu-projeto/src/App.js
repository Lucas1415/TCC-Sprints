import { Link } from 'react-router-dom';
import './App.css';
import menu from "./logo-menu.png";
import GlobalStyle from './global';
import RouterApp from './routes';
import { AuthProvider } from './contexts/auth';

function App() {
  return (
      <AuthProvider>
      <RouterApp/>
      <GlobalStyle/>
      </AuthProvider>
  );
}

export default App;
