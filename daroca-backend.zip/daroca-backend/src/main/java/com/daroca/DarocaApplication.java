package com.daroca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DarocaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DarocaApplication.class, args);
	}

}
