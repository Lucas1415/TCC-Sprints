package com.daroca.models;

import jakarta.persistence.*;

@Entity
@Table

public class Customer {
    @Id // o id vai ser uma primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // id auto incremento

    private Integer id;
    @Column(length = 50, nullable = false)
    private String name;
    @Column(length = 100)
    private String email;
    @Column
    private Double Longitude;
    @Column
    private Double Latitude;

    public Customer(Integer id, String name, String email, Double Longitude, Double Latitude){
        this.id = id;
        this.name = name;
        this.email = email;
        this.Longitude = Longitude;
        this.Latitude = Latitude;
    }

    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }


    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }


    public Double getLongitude() {
        return Longitude;
    }
    public void setLongitude(Double longitude) {
        Longitude = longitude;
    }


    public Double getLatitude() {
        return Latitude;
    }
    public void setLatitude(Double latitude) {
        Latitude = latitude;
    }

    public boolean equals(Customer other){
        return this.id.equals(other.getId()) && this.name.equals(other.getName());
    }

    public String toString() {
        return "Customer[id = " + this.id + ", name = " + this.name + "]";
    }
}
