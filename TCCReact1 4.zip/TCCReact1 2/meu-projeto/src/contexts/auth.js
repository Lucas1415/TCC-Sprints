import React, { createContext, useEffect, useState } from 'react';
import axios from 'axios';

export const AuthContext = createContext({});

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        const userToken = localStorage.getItem("user_token");
        if (userToken) {
            const tokenData = JSON.parse(userToken);
        }
    }, []);

    const signin = async (email, password) => {
        try {
            const response = await axios.post('http://localhost:8080/usuario', { email, password });
            const { token } = response.data;

            localStorage.setItem("user_token", JSON.stringify({ email, token }));
            setUser({ email });
        } catch (error) {
            console.error("Erro ao tentar fazer login:", error);
            if (error.response && error.response.status === 401) {
                return "E-mail ou senha incorretos";
            } else {
                return "Erro ao tentar fazer login";
            }
        }
    };

    const signup = async (email, password) => {
        try {
            const response = await axios.post('http://localhost:8080/usuario', { email, password });
            return response.data; // Retorna a mensagem de sucesso
        } catch (error) {
            console.error("Erro ao tentar se cadastrar:", error);
            if (error.response) {
                return error.response.data; // Retorna a mensagem de erro da API
            }
            return "Erro ao tentar se cadastrar";
        }
    };

    const signout = () => {
        setUser(null);
        localStorage.removeItem("user_token");
    };

    return (
        <AuthContext.Provider value={{ user, signed: !!user, signin, signup, signout }}>
            {children}
        </AuthContext.Provider>
    );
};
