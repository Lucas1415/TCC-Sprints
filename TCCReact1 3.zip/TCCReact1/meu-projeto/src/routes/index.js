import React from 'react';
import { Fragment } from "react";
import {BrowserRouter,Route,Routes} from "react-router-dom";
import Home from "../pages/Home";
import Signin from "../pages/Signin";
import Signup from "../pages/Signup";
import useAuth from "../hooks/useAuth";
import Segunda from "../pages/Semana/Segunda"; 
import Terca from "../pages/Semana/Terca"; 
import Quarta from "../pages/Semana/Quarta"; 
import Quinta from "../pages/Semana/Quinta"; 
import Sexta from "../pages/Semana/Sexta"; 
import Sabado from "../pages/Semana/Sabado"; 
import Domingo from "../pages/Semana/Domingo"; 

const Private = ({Item}) => {
    const { signed} = useAuth();

    return signed > 0 ? <Item /> : <Signin />;
};

const RouterApp = () => {
    return(
        <BrowserRouter>
        <Fragment>
            <Routes>
                <Route exact path="/home" element={<Private Item={Home} />} />
                <Route path="/" element={<Signin />} />
                <Route exact path="signup" element={<Signup />} />
                <Route path="*" element={<Signin />} />
                <Route path="/Segunda" element={<Segunda/>}/>
                <Route path="/Terca" element={<Terca/>}/>
                <Route path="/Quarta" element={<Quarta/>}/>
                <Route path="/Quinta" element={<Quinta/>}/>
                <Route path="/Sexta" element={<Sexta/>}/>
                <Route path="/Sabado" element={<Sabado/>}/>
                <Route path="/Domingo" element={<Domingo/>}/>
            </Routes>
        </Fragment>
        </BrowserRouter>
    );
};


export default RouterApp;