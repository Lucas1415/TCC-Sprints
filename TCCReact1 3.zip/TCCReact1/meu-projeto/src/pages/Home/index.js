// src/pages/Carrossel/index.js
import React from 'react';
import { Link } from 'react-router-dom';
import * as C from "./style";
import WeekTable from '../../components/WeekTable/WeekTable';
import Logo_top from '../Home/Logo_top.jpeg';
import SlideImg from '../Home/SlideImg.png';
import { useNavigate } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';

const Home = () => {
    const { signout } = useAuth();
    const navigate = useNavigate();

    const handleSignout = () => {
        signout();
        navigate('/');
    };

    return (
        <C.MenuContainer>
            <C.Menu>
                <C.MenuItem>
                    <C.Logo>
                        <img src={Logo_top} alt="Logo" />
                    </C.Logo>
                </C.MenuItem>
                <C.MenuItem>
                    <Link to="/h
                    ome">Home</Link>
                </C.MenuItem>
                <C.MenuItem>
                    <C.DropdownTrigger>
                        <C.MenuItem>
                            <Link>Semana</Link>
                        </C.MenuItem>
                        <C.DropdownContent>
                            <Link to="/Segunda">Segunda</Link>
                            <Link to="/Terca">Terça</Link>
                            <Link to="/Quarta">Quarta</Link>
                            <Link to="/Quinta">Quinta</Link>
                            <Link to="/Sexta">Sexta</Link>
                            <Link to="/Sabado">Sábado</Link>
                            <Link to="/Domingo">Domingo</Link>
                        </C.DropdownContent>
                    </C.DropdownTrigger>
                </C.MenuItem>
                <C.MenuItem>
                    <Link to="/Cuidador">Cuidador</Link>
                </C.MenuItem>
            </C.Menu>
            <C.SlideImage src={SlideImg} alt="Carousel" />
            <C.InicialConteiner>
                <WeekTable />
            </C.InicialConteiner>
        </C.MenuContainer>
    );
};

export default Home;
