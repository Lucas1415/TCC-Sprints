import styled from 'styled-components';

export const MenuContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;            /* Centraliza o conteúdo horizontalmente */
  justify-content: center;
  padding: 10px;
  width: 100%;
  background: linear-gradient(to bottom, #E6E6FA,  #800080); /* Degradê do roxo ao lilás */
  min-height: 100vh;             /* Garante que o fundo cubra toda a altura da tela */
  padding-top: 100px;            /* Adiciona um espaçamento no topo para acomodar o menu fixo */
`;


export const Menu = styled.nav`
  display: flex;
  justify-content: center;
  background-color: black;
  height: 100px;
  align-items: center;   /* Alinha os itens no centro verticalmente */
  flex-direction: row;   /* Garante que os itens estejam alinhados horizontalmente */
  width: 100%;           /* Garante que o menu ocupe toda a largura disponível */
  position: fixed;       /* Fixa o menu no topo da página */
  top: 0;                /* Posiciona o menu no topo */
  z-index: 1000;         /* Garante que o menu fique acima de outros elementos */
`;

export const WeekTable = styled.div`
  height: 500px;
  width: 100%; /* Ocupa a largura total disponível */
  display: flex;
  justify-content: center; /* Centraliza o conteúdo horizontalmente */
  align-items: center; /* Centraliza o conteúdo verticalmente */
`;

export const MenuItem = styled.div`
  margin: 0 15px;
  a {
    color: white;
    text-decoration: none;
    font-size: 18px;
  }
  a:hover {
    text-decoration: underline;
  }
`;

export const InicialConteiner = styled.div`
  margin-top: 20px;
  padding: 20px;
  display: flex;
  justify-content: center; /* Centraliza o conteúdo horizontalmente */
  align-items: center; /* Centraliza o conteúdo verticalmente */
  width: 100%;
`;
