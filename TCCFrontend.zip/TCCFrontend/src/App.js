import React from 'react';
import './App.css';
import GlobalStyle from './global';
import RouterApp from './routes';
import { AuthProvider } from './contexts/auth';

const App = () => {
  return (
    <AuthProvider>
      <RouterApp />
      <GlobalStyle />
    </AuthProvider>
  );
}

export default App;
