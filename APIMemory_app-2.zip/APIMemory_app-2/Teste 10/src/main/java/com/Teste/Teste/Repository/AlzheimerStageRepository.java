package com.Teste.Teste.Repository;

import com.Teste.Teste.Models.AlzheimerStage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlzheimerStageRepository extends JpaRepository<AlzheimerStage, Integer> {
}