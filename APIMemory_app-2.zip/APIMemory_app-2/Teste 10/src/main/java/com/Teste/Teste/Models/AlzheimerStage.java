package com.Teste.Teste.Models;

import jakarta.persistence.*;

@Entity
@Table(name = "alzheimer_stages")
public class AlzheimerStage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String title;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String description;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String caretakerTip;

    @Column(columnDefinition = "TEXT", nullable = false)  // Adicionando o campo name
    private String name;  // O campo name que é necessário no banco de dados

    // Getters e Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCaretakerTip() {
        return caretakerTip;
    }

    public void setCaretakerTip(String caretakerTip) {
        this.caretakerTip = caretakerTip;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}