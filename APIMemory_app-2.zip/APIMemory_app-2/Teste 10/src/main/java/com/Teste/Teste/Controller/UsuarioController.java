package com.Teste.Teste.Controller;

import com.Teste.Teste.Models.Usuario;
import com.Teste.Teste.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api") // Define o recurso da API
public class UsuarioController {

    private final UsuarioRepository usuarioRepository;

    @Autowired
    public UsuarioController(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    // Retorna todos os usuários
    @GetMapping ("/usuarios")
    public ResponseEntity<List<Usuario>> getAllUsuarios() {
        List<Usuario> usuarios = usuarioRepository.findAll();
        return ResponseEntity.ok(usuarios);
    }

    // Retorna um usuário específico por ID
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> getUsuarioById(@PathVariable Long id) {
        return usuarioRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Deleta um usuário por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUsuario(@PathVariable Long id) {
        if (usuarioRepository.existsById(id)) {
            usuarioRepository.deleteById(id);
            return ResponseEntity.noContent().build(); // 204 No Content
        } else {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
    }

    // Cadastro de novo usuário
    @PostMapping ("/registrar")
    public ResponseEntity<Usuario> saveUsuario(@RequestBody Usuario newUsuario) {
        Usuario savedUsuario = usuarioRepository.save(newUsuario);
        return ResponseEntity.status(201).body(savedUsuario); // 201 Created
    }

    // Método para login
    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(@RequestBody Usuario loginData) {
        String email = loginData.getEmail();
        String senha = loginData.getSenha();

        // Log para verificar os dados recebidos
        System.out.println("Email recebido: " + email);
        System.out.println("Senha recebida: " + senha);

        Usuario usuario = UsuarioRepository.findByEmail(email);

        if (usuario != null) {
            // Verifique a senha do usuário (pode ser necessário ajustar para comparação de senhas criptografadas)
            System.out.println("Senha armazenada no banco: " + usuario.getSenha());
            if (usuario.getSenha().equals(senha)) {
                // Retorna uma resposta JSON com a mensagem de sucesso
                Map<String, String> response = new HashMap<>();
                response.put("message", "Login bem-sucedido!");
                return ResponseEntity.ok(response);
            } else {
                // Caso as senhas não coincidam
                Map<String, String> response = new HashMap<>();
                response.put("message", "E-mail ou senha incorretos");
                return ResponseEntity.status(401).body(response);
            }
        } else {
            // Caso o usuário não exista
            Map<String, String> response = new HashMap<>();
            response.put("message", "E-mail ou senha incorretos");
            return ResponseEntity.status(401).body(response);
        }
    }


    // Atualiza um usuário por ID
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> updateUsuario(@RequestBody Usuario updatedUsuario, @PathVariable Long id) {
        return usuarioRepository.findById(id)
                .map(usuario -> {
                    usuario.setName(updatedUsuario.getName());
                    usuario.setEmail(updatedUsuario.getEmail());
                    usuario.setSenha(updatedUsuario.getSenha());
                    Usuario savedUsuario = usuarioRepository.save(usuario);
                    return ResponseEntity.ok(savedUsuario); // 200 OK
                })
                .orElse(ResponseEntity.notFound().build()); // 404 Not Found
    }
}
