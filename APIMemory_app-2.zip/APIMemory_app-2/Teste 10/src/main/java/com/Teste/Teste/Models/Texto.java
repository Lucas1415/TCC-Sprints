package com.Teste.Teste.Models;


import jakarta.persistence.*;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;



@Entity
public class Texto {

    @Id
    @GeneratedValue(strategy = jakarta.persistence.GenerationType.IDENTITY)
    private Integer id;

    private String titulo;  // Título da página
    private String subtitulo;  // Subtítulo
    private String descricao;  // Descrição principal
    private String titulo2;  // Outro título (exemplo: O que é o Alzheimer?)
    private String descricao2;  // Outra descrição
    private String microtexto;  // Microtexto
    private String quemSomosTitulo;  // Quem somos? Título
    private String quemSomosDescricao;  // Quem somos? Descrição
    private String rodape;  // Rodapé

    // Getters e Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getSubtitulo() {
        return subtitulo;
    }

    public void setSubtitulo(String subtitulo) {
        this.subtitulo = subtitulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTitulo2() {
        return titulo2;
    }

    public void setTitulo2(String titulo2) {
        this.titulo2 = titulo2;
    }

    public String getDescricao2() {
        return descricao2;
    }

    public void setDescricao2(String descricao2) {
        this.descricao2 = descricao2;
    }

    public String getMicrotexto() {
        return microtexto;
    }

    public void setMicrotexto(String microtexto) {
        this.microtexto = microtexto;
    }

    public String getQuemSomosTitulo() {
        return quemSomosTitulo;
    }

    public void setQuemSomosTitulo(String quemSomosTitulo) {
        this.quemSomosTitulo = quemSomosTitulo;
    }

    public String getQuemSomosDescricao() {
        return quemSomosDescricao;
    }

    public void setQuemSomosDescricao(String quemSomosDescricao) {
        this.quemSomosDescricao = quemSomosDescricao;
    }

    public String getRodape() {
        return rodape;
    }

    public void setRodape(String rodape) {
        this.rodape = rodape;
    }
}
