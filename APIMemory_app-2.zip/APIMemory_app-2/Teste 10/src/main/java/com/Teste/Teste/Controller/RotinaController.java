package com.Teste.Teste.Controller;




import com.Teste.Teste.Models.Rotina;
import com.Teste.Teste.Repository.RotinaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/rotinas")// para definir o recurso da API

public class RotinaController {
    @Autowired
    private RotinaRepository repository;

        @GetMapping
        public List<Rotina> getAll() {
            return repository.findAll();  // Retorna todas as rotinas (com título, descrição, e imagem)
        }


    @GetMapping("/rotina/{id}")
    public Optional<Rotina> one (@PathVariable Integer id){
        return repository.findById(id);
    }

    @DeleteMapping("/rotina/{id}")
    public void delete(@PathVariable Integer id) {repository.deleteById(id);}

    @PostMapping("/rotina")
    public Rotina save(@RequestBody Rotina newRotina){
        return repository.save(newRotina);
    }

    @PostMapping("/rotina/{id}")
    public Rotina replace(@RequestBody Rotina newRotina){
        return repository.save(newRotina);}




}
