package com.Teste.Teste.Controller;
import com.Teste.Teste.Models.Texto;
import com.Teste.Teste.Repository.TextoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/texto")
public class TextoController {

    @Autowired
    private TextoRepository textoRepository;

        // Método GET para pegar todos os textos
        @GetMapping("/textos")
        public List<Texto> getTextos() {
            return textoRepository.findAll();
        }


        @PostMapping("/insert")
        public Texto addTexto(@RequestBody Texto novoTexto) {
            return textoRepository.save(novoTexto);
        }

    // Método PUT para atualizar um texto existente
    @PutMapping("/update/{id}")
    public Texto updateTexto(@PathVariable Integer id, @RequestBody Texto textoAtualizado) {
        Optional<Texto> textoExistente = textoRepository.findById(id);

        if (textoExistente.isPresent()) {
            Texto texto = textoExistente.get();

            // Atualiza os campos conforme o conteúdo fornecido
            texto.setTitulo(textoAtualizado.getTitulo());
            texto.setSubtitulo(textoAtualizado.getSubtitulo());
            texto.setDescricao(textoAtualizado.getDescricao());
            texto.setTitulo2(textoAtualizado.getTitulo2());
            texto.setDescricao2(textoAtualizado.getDescricao2());
            texto.setMicrotexto(textoAtualizado.getMicrotexto());
            texto.setQuemSomosTitulo(textoAtualizado.getQuemSomosTitulo());
            texto.setQuemSomosDescricao(textoAtualizado.getQuemSomosDescricao());
            texto.setRodape(textoAtualizado.getRodape());

            return textoRepository.save(texto);
        } else {
            throw new RuntimeException("Texto com ID " + id + " não encontrado.");
        }
    }
}






