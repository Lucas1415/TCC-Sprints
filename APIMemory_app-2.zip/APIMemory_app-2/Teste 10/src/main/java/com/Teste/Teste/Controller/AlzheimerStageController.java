package com.Teste.Teste.Controller;

import com.Teste.Teste.Models.AlzheimerStage;
import com.Teste.Teste.Repository.AlzheimerStageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/alzheimer")
public class AlzheimerStageController {

    @Autowired
    private AlzheimerStageRepository repository;

    // Método GET para buscar todos os estágios
    @GetMapping
    public List<AlzheimerStage> getAllStages() {
        return repository.findAll();
    }

    // Método GET para buscar estágio por ID
    @GetMapping("/{id}")
    public AlzheimerStage getStageById(@PathVariable Integer id) {
        return repository.findById(id).orElse(null);
    }

    // Método POST para criar um novo estágio
    @PostMapping("/stage")
    public ResponseEntity<?> createStage(@RequestBody AlzheimerStage alzheimerStage) {
        try {
            AlzheimerStage savedStage = repository.save(alzheimerStage);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedStage);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erro ao salvar o estágio: " + e.getMessage());
        }
    }

    // Método PUT para atualizar um estágio existente
    @PutMapping("/{id}/stage")
    public ResponseEntity<?> updateStage(@PathVariable Integer id, @RequestBody AlzheimerStage updatedStage) {
        // Tenta encontrar o estágio pelo ID
        var optionalStage = repository.findById(id);

        if (optionalStage.isPresent()) {
            AlzheimerStage existingStage = optionalStage.get();

            // Atualiza os campos do estágio (verifica se os campos estão presentes e não são nulos)
            if (updatedStage.getName() != null && !updatedStage.getName().isEmpty()) {
                existingStage.setName(updatedStage.getName());
            }
            if (updatedStage.getDescription() != null && !updatedStage.getDescription().isEmpty()) {
                existingStage.setDescription(updatedStage.getDescription());
            }
            if (updatedStage.getTitle() != null) { // Aceita strings vazias para limpar o campo
                existingStage.setTitle(updatedStage.getTitle());
            }
            if (updatedStage.getCaretakerTip() != null) {
                existingStage.setCaretakerTip(updatedStage.getCaretakerTip());
            }

            // Salva e retorna o estágio atualizado
            AlzheimerStage savedStage = repository.save(existingStage);
            return ResponseEntity.ok(savedStage);
        } else {
            // Retorna 404 caso o estágio não seja encontrado
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Estágio não encontrado.");
        }
    }


    // Método DELETE para excluir um estágio pelo ID
    @DeleteMapping("/{id}/stage")
    public ResponseEntity<?> deleteStage(@PathVariable Integer id) {
        // Tenta encontrar o estágio pelo ID
        var optionalStage = repository.findById(id);

        if (optionalStage.isPresent()) {
            // Remove o estágio do banco de dados
            repository.deleteById(id);
            return ResponseEntity.ok("Estágio excluído com sucesso.");
        } else {
            // Retorna 404 caso o estágio não seja encontrado
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Estágio não encontrado.");
        }
    }


}