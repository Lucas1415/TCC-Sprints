import React, { createContext, useState, useEffect } from 'react';
import api from '../Api/Api';  // Seu arquivo de configuração de API

export const AuthContext = createContext({});

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  // Verifica se o usuário está autenticado com base no token
  useEffect(() => {
    const token = localStorage.getItem("user_token");

    if (token) {
      // Se tiver token, faz uma requisição para obter os dados do usuário
      api
        .get("/usuario/")
        .then(response => {
          setUser(response.data);  // Atualiza o estado do usuário
        })
        .catch(err => {
          console.error("Erro ao buscar usuário: ", err);
          localStorage.removeItem("user_token");  // Remove o token se houver erro
        });
    }
  }, []);  // O efeito só será executado uma vez, após o primeiro render

  return (
    <AuthContext.Provider value={{ user }}>
      {children}
    </AuthContext.Provider>
  );
};
