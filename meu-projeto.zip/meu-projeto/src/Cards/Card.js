import React from 'react';
import styled from 'styled-components';
import Button from '../components/Button';
import * as C from './style';
import imgJogo from '../images/imageJogo.jpg';
import imgCaminhada from '../images/imgCaminhada1.jpg';
import imageSrc from '../images/imgPasseio1.jpg';
const Card = ({ title, description, imageSrc }) => {
    return (
     <C.CardWrapper>
        <C.Image src={imageSrc} alt="Imagem do card" />
        <C.Title>{title}</C.Title>
        <C.Description>{description}</C.Description>
        <Button> LEIA MAIS</Button>
     </C.CardWrapper>
    );
};
export default Card;
