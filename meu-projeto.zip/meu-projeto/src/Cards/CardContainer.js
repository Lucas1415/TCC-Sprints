import React from 'react';
import Card from './Card';
import { Container } from './style';  // Importação correta
import imgJogo from '../images/imageJogo.jpg';
import imgCaminhada from '../images/imgCaminhada1.jpg';
import imgPasseio from '../images/imgPasseio1.jpg';

const CardContainer = () => {
  return (
    <Container>
      <Card 
       imageSrc= '../images/imageJogo.jpg'
        title="Vacinação contra Herpes Zoster: Protegendo sua Saúde" 
        description="A vacinação contra Herpes Zoster já está disponível..." 
      />
      <Card 
         imageSrc="../images/imgCaminhada1.jpg"
        title="Descubra Tudo Sobre Fibromialgia: Sintomas, Diagnóstico e Tratamento" 
        description="Fibromialgia é uma condição médica crônica caracterizada por dor..." 
      />
      <Card 
        imageSrc="../images/imgPasseio1.jpg" 
        title="Tudo o Que Você Precisa Saber Sobre Epicondilite (dor no cotovelo)" 
        description="Tudo o que você precisa saber sobre epicondilite (dor no cotovelo)..." 
      />
    </Container>
  );
};

export default CardContainer;
