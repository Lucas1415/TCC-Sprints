import styled from "styled-components";

export const CardWrapper = styled.div`
  background-color: #f9f9f9;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  text-align: left;
  width: 300px;
  margin: 20px;
`;

// Novo estilo para a imagem
export const Image = styled.img`
  width: 100%;
  height: auto;
  border-radius: 8px;
  margin-bottom: 10px;
`;

export const Title = styled.h3`
  color: #333;
  font-size: 18px;
  margin-bottom: 10px;
`;

export const Description = styled.p`
  color: #666;
  font-size: 14px;
  line-height: 1.5;
  margin-bottom: 20px;
`;

export const Button = styled.button`
  background-color: #ff7f50;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;

  &:hover {
    background-color:#ff6347;
  }
`;

export const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  padding: 20px;
  background-color: #e6f7ff;
`;
