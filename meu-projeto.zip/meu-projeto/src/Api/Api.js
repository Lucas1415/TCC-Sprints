import axios from "axios";

const api = axios.create({
  baseURL: "https:/api/**",  // Coloque o baseURL da sua API aqui
});

// Adiciona o interceptor para incluir o token de autorização em todas as requisições
api.interceptors.request.use(config => {
  const token = localStorage.getItem("authToken"); // Obtém o token armazenado

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
}, error => {
  // Caso ocorra erro ao configurar a requisição, ele será tratado aqui
  return Promise.reject(error);
});

export default api;
