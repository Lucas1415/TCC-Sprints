// src/pages/Cuidador/index.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../components/Button';
import useAuth from '../../hooks/useAuth';
import * as C from "./style";
import { Link } from 'react-router-dom';
import WeekTable from '../../components/WeekTable/WeekTable';
import Logo_top from '../Home/Logo_top.jpeg';

const Cuidador = () => {
   

    return (
        <C.MenuContainer>
            <C.Menu>
                <C.MenuItem>
                    <C.Logo>
                        <img src={Logo_top} alt="Logo" />
                    </C.Logo>
                </C.MenuItem>
                <C.MenuItem>
                    <Link to="/home">Home</Link>
                </C.MenuItem>
                <C.MenuItem>
                    <C.DropdownTrigger>
                        <Link>Semana</Link>
                        <C.DropdownContent>
                            <Link to="/Segunda">Segunda</Link>
                            <Link to="/Terca">Terça</Link>
                            <Link to="/Quarta">Quarta</Link>
                            <Link to="/Quinta">Quinta</Link>
                            <Link to="/Sexta">Sexta</Link>
                            <Link to="/Sabado">Sábado</Link>
                            <Link to="/Domingo">Domingo</Link>
                        </C.DropdownContent>
                    </C.DropdownTrigger>
                </C.MenuItem>
                <C.MenuItem>
                    <Link to="Cuidador">Cuidador</Link>
                </C.MenuItem>
            </C.Menu>
       
            <C.InicialConteiner>
                <WeekTable/>
            </C.InicialConteiner>
        </C.MenuContainer>
        
    );
};

export default Cuidador;
