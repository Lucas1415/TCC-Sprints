package com.example.projetotcc;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Cadastro extends AppCompatActivity {

    private EditText etNomeCompleto, etEmail, etSenhaCadastro;
    private Button btnCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        etNomeCompleto = findViewById(R.id.etNomeCompleto);
        etEmail = findViewById(R.id.etEmail);
        etSenhaCadastro = findViewById(R.id.etSenhaCadastro);
        btnCadastrar = findViewById(R.id.btnCadastrar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implementar lógica de cadastro aqui
                String nomeCompleto = etNomeCompleto.getText().toString();
                String email = etEmail.getText().toString();
                String senha = etSenhaCadastro.getText().toString();

                if (nomeCompleto.isEmpty() || email.isEmpty() || senha.isEmpty()) {
                    Toast.makeText(Cadastro.this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else {
                    // Chamada para a API de cadastro
                }
            }
        });
    }
}
