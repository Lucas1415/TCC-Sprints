package com.Teste.Teste.Controller;

import com.Teste.Teste.Models.Usuario;
import com.Teste.Teste.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api") // Define o recurso da API
public class UsuarioController {

    private final UsuarioRepository usuarioRepository;

    @Autowired
    public UsuarioController(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    // Retorna todos os usuários
    @GetMapping ("/usuarios")
    public ResponseEntity<List<Usuario>> getAllUsuarios() {
        List<Usuario> usuarios = usuarioRepository.findAll();
        return ResponseEntity.ok(usuarios);
    }

    // Retorna um usuário específico por ID
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> getUsuarioById(@PathVariable Long id) {
        return usuarioRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Deleta um usuário por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUsuario(@PathVariable Long id) {
        if (usuarioRepository.existsById(id)) {
            usuarioRepository.deleteById(id);
            return ResponseEntity.noContent().build(); // 204 No Content
        } else {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
    }

    // Cadastro de novo usuário
    @PostMapping ("/registrar")
    public ResponseEntity<Usuario> saveUsuario(@RequestBody Usuario newUsuario) {
        Usuario savedUsuario = usuarioRepository.save(newUsuario);
        return ResponseEntity.status(201).body(savedUsuario); // 201 Created
    }

    // Método para login
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Usuario loginData) {
        String email = loginData.getEmail();
        String senha = loginData.getSenha();

        // Fix: Use the usuarioRepository instance, not static access
        Usuario usuario = UsuarioRepository.findByEmail(email);
        if (usuario != null && usuario.getSenha().equals(senha)) {
            return ResponseEntity.ok("Login bem-sucedido!"); // Retornar o token se implementar
        } else {
            return ResponseEntity.status(401).body("E-mail ou senha incorretos"); // 401 Unauthorized
        }
    }

    // Atualiza um usuário por ID
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> updateUsuario(@RequestBody Usuario updatedUsuario, @PathVariable Long id) {
        return usuarioRepository.findById(id)
                .map(usuario -> {
                    usuario.setName(updatedUsuario.getName());
                    usuario.setEmail(updatedUsuario.getEmail());
                    usuario.setSenha(updatedUsuario.getSenha());
                    Usuario savedUsuario = usuarioRepository.save(usuario);
                    return ResponseEntity.ok(savedUsuario); // 200 OK
                })
                .orElse(ResponseEntity.notFound().build()); // 404 Not Found
    }
}
