package com.Teste.Teste.Repository;



import com.Teste.Teste.Models.Rotina;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RotinaRepository extends JpaRepository<Rotina, Integer> {
}
