import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../components/Button';
import useAuth from '../../hooks/useAuth';
import * as C from "./style";
import { Link } from 'react-router-dom';
import WeekTable from '../../components/WeekTable/WeekTable'; // Importe o WeekTable
import Logo_top from './Logo_top.jpeg';
const Home = () => {
    const { signout } = useAuth();
    const navigate = useNavigate();

    const handleSignout = () => {
        signout();
        navigate('/');
    };

    return (
       <C.MenuContainer>
                <script src="//code.tidio.co/7d5krcbcz0g5bfz4ebh0irgo2rnirhnt.js"></script>
                <C.Logo>
                <img src={Logo_top} alt="Logo" /> 
                </C.Logo>
            <C.Menu>
            <C.MenuItem>
                <Link to="/home">Home</Link>
            </C.MenuItem>
            <C.MenuItem>
                <Link to="/semana">Semana</Link>
            </C.MenuItem>
            <C.Menuitem>
                <Link to=" ">Cuidador</Link>
            </C.Menuitem>
            </C.Menu>
            <C.InicialConteiner>
               
                <WeekTable />
            </C.InicialConteiner>
            <Button Text="Sair" onClick={handleSignout} />
        </C.MenuContainer>
    );
};

export default Home;
 