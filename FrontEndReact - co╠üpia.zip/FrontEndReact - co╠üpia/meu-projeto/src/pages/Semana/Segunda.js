import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../components/Button';
import useAuth from '../../hooks/useAuth';
import * as C from "./style";
import { Link } from 'react-router-dom';
import WeekTable from '../../components/WeekTable/WeekTable'; // Importe o WeekTable
import Logo_top from '../Home/Logo_top.jpeg';
const Segunda = () => {
    const { signout } = useAuth();
    const navigate = useNavigate();

    const handleSignout = () => {
        signout();
        navigate('/');
    };

    return (
        <C.MenuContainer>
                <script src="//code.tidio.co/7d5krcbcz0g5bfz4ebh0irgo2rnirhnt.js"></script>
              
           <C.Menu>
            <C.MenuItem>
                <C.Logo>
            <img src={Logo_top} alt="Logo" /> 
            </C.Logo>
            </C.MenuItem>
            <C.MenuItem>
                <Link to="/home">Home</Link>
            </C.MenuItem>
            <C.MenuItem>
            <C.DropdownTrigger>
      <C.MenuItem>
        <Link >Semana</Link>
      </C.MenuItem>
      <C.DropdownContent>
      <Link to="/Segunda">Segunda</Link>
        <Link to="/Terca"> Terça</Link>
        <Link to="/Quarta">Quarta</Link>
        <Link to="/Quinta">Quinta</Link>
        <Link to="/Sexta">Sexta</Link>
        <Link to="/Sabado">Sabado</Link>
        <Link to="/Domingo">Domingo</Link>
      </C.DropdownContent>
    </C.DropdownTrigger>
        
            </C.MenuItem>
            <C.MenuItem>
                <Link to="Cuidador">Cuidador</Link>
            </C.MenuItem>
           </C.Menu>
           <C.InicialConteiner>
                

            </C.InicialConteiner>
            <C.FooterContainer>
         <C.FooterText>
             © 2024 Memory Keys - Todos os direitos reservados
         </C.FooterText>
         <C.FooterIcons>
             <C.FooterLink href="#">Facebook</C.FooterLink>
             <C.FooterLink href="#">Instagram</C.FooterLink>
             <C.FooterLink href="#">Twitter</C.FooterLink>
         </C.FooterIcons>
     </C.FooterContainer>
        </C.MenuContainer>
    );
};

export default Segunda;
