import axios from "axios";

const api = axios.create({
  baseURL: "https://api.github.com",
});

// Adiciona um interceptor para incluir o token de autorização em todas as requisições
api.interceptors.request.use(config => {
  const token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9"; // Token para teste

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});

export default api;
